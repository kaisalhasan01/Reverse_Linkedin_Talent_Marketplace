---
name: new-calculator
description: Add a new calculator page to the AdulthoodCalc static site following its zero-dependency, GDPR-clean architecture. Use when Kais wants a new calculator (roadmap ideas - rent-vs-buy, car total cost, inflation, net worth, salary, latte factor).
---

# New calculator page

**When to use:** Kais wants a new calculator on AdulthoodCalc (`/Users/Kais/Adulthood calc/`).

## Steps, in order (from the README's own recipe + the real code)

1. Copy an existing page (e.g. `loan.html`) and its logic file in `assets/js/pages/`.
2. Update title, meta description, inputs, and the lesson text under the calculator (every page teaches, not just computes).
3. Write the `update()` function in the page's JS file: read inputs with `AC.num('id')`, write results to the result cards, draw the chart with `AC.charts.line` or `AC.charts.donut`. Register `AC.onRecalc(update)` and call `update()` once.
4. Add the page to `sitemap.xml`, the grid on `index.html`, and the "Keep going" links on related pages.
5. Test locally: `cd "/Users/Kais/Adulthood calc" && python3 -m http.server 4173` → check the math against a hand calculation, dark mode (automatic), mobile view (the site is mobile-first — it gets screen-recorded for TikTok), and currency switching (`AC.fmt` must format all outputs).

## Example of a good final output (the real pattern, from `assets/js/pages/savings-goal.js`)

```javascript
/* Savings goal calculator */
(function () {
  'use strict';
  var MAX_MONTHS = 1200;

  function update() {
    var goal = AC.num('goal');
    var current = AC.num('current');
    var monthly = AC.num('monthly');
    var apy = AC.num('apy');

    var bal = current, deposited = current, m = 0;
    var series = [bal];
    var reached = bal >= goal;

    while (!reached && m < MAX_MONTHS) {
      m++;
      bal += bal * (apy / 100) / 12;
      bal += monthly;
      deposited += monthly;
      series.push(bal);
      if (bal >= goal) reached = true;
    }
    // ... write results via element.textContent + AC.fmt(...),
    // friendly warning when the goal is unreachable, then chart the series.
  }
  // register + first run (same on every page)
  AC.onRecalc(update);
  update();
})();
```

Note the traits: plain IIFE, `'use strict'`, `var`, a hard iteration cap, human results ("Done ✓", a real month/year date), and an encouraging warning message instead of an error.

## Mistakes to avoid

- **Adding any framework, CDN, font, analytics or external call.** The architecture is deliberately 100% static with zero external requests — the README ties this to GDPR (Google Fonts embedding has lost GDPR rulings) and to AdSense-friendliness. One `<script src="https://...">` breaks both the promise and the CSP in `_headers`.
- **Shipping without a chart or with an ugly one.** Kais's explicit correction during the build: "De ska ha fina grafer och vara esthetically pleasing!" Every calculator has an SVG chart from the in-house `charts.js`.
- **Forgetting step 4.** A page missing from `sitemap.xml` + the index grid + "Keep going" links is invisible to both SEO and users — the README lists this as its own step for a reason.
- **Hardcoding a currency.** All money output goes through `AC.fmt`; the user's USD/EUR/GBP/SEK choice must reformat everything.
- **Skipping the lesson text.** The site's positioning is "calculators that teach adulthood"; a bare number-cruncher doesn't fit.
