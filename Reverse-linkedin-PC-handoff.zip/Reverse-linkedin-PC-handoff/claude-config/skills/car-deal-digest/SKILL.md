---
name: car-deal-digest
description: Run the Swedish Car Deal Finder pipeline and produce a personalized top-deals digest with TCO and known-issues briefing. Use when Kais wants fresh Blocket deals or to test the pipeline.
---

# Car deal digest

**When to use:** Kais wants car deals from Blocket, or wants to run/verify the car-deal-finder pipeline (`/Users/Kais/Projects/car-deal-finder/`).

## Steps, in order

1. Activate the environment:
   `cd /Users/Kais/Projects/car-deal-finder && source .venv/bin/activate`
2. Check `.env` for `BRIGHTDATA_API_KEY` and `BRIGHTDATA_UNLOCKER_ZONE`. If missing, only **sample mode** works — say so explicitly and don't present its output as real listings. (As of July 2026 there is no `.env`; real-data mode is blocked until Kais creates a Bright Data Web Unlocker zone.)
3. First real run ever: probe first to confirm the parser —
   `python -m scrapers.blocket_brightdata --probe "https://www.blocket.se/bilar/sok?q=volvo"`
   The probe saves HTML + screenshot to `debug/` and reveals Blocket's actual `__NEXT_DATA__` field paths so the `TODO`s in `scrapers/blocket.py` (`_iter_raw_ads` / `_normalize`) can be finalized. Do not run the full pipeline on real data before the paths are confirmed.
4. Run the ETL:
   real: `python -m pipeline.run --source blocket-bd --query "volvo v60" --pages 2`
   demo: `python -m pipeline.run --source sample --limit 200`
5. Ask for (or reuse) Kais's buyer profile, then generate the shortlist:
   `python -m pipeline.recommend --budget 220000 --min-year 2016 --drivetrain AWD,FWD --body Kombi,SUV --max-insurance 800`
6. Relay the shortlist with all four layers intact: match score, price vs value, cost of ownership per year, and the known-issues briefing with negotiation room.

## Example of a good final output (one entry, in the exact format `pipeline/recommend.py` prints)

```
==========================================================================
  DINA TOPPMATCHNINGAR
  Profil: budget ≤ 220 000 kr · AWD/FWD · Kombi/SUV · försäkring ≤ 800/mån · ≥ 2016
==========================================================================

[1] Volvo V60 2017   — Match 87/100
    Pris 189 000 kr  (värde ~208 000 kr, rabatt -9%)  ·  112 000 km
    Kombi · FWD · diesel · 190 hk · pålitlighet 4/5
    Kostnad/år ~24 300 kr  (försäkring 640/mån, bränsle 9 800, skatt 1 730, reparationsreserv 6 000)
    Att kolla / pruta på:
      ⚠ Slitage i framvagn (länkarmar) vanligt över 10 000 mil
         → Lyssna efter knäppningar vid lågfartssvängar; kolla senaste besiktningsprotokollet
    💬 Förhandlingsutrymme att verifiera: ~8 000 kr
```

## Mistakes to avoid

- **Ranking by discount alone.** This was Kais's explicit mid-project correction: he'd rather "hjälpa privata personer än företag" — the tool must match cars to *a person* (insurance budget, drivetrain, fuel economy, body type, reliability, TCO), not just chase the biggest price gap. The match score exists because of that correction.
- **Presenting sample data as real deals.** Sample mode is an offline demo; label it.
- **Dropping the known-issues briefing.** The "vanliga fel / att kolla / pruta på" section is the product's differentiator and gives real negotiation leverage (the README's Audi A4 oil-burner example ≈ 15 000 kr).
- **Trusting the discount % blindly.** The README's own roadmap flags that the current cohort-median fallback valuation inflates discounts until year/age-aware valuation is implemented — caveat it.
- **Skipping the probe.** The JSON field paths are marked `TODO` until confirmed against a live response; running the pipeline first produces silently empty/wrong data.
