---
name: fusklapp
description: Generate a one-page Swedish exam cheat sheet (fusklapp) for one of Kais's LiU courses from the course folder of lectures and past exams. Use when Kais asks for a "fusklapp", "formelblad" or cheat sheet for a course code (e.g. TMHL24, 770G36).
---

# Fusklapp generator

**When to use:** Kais names a course code and wants a fusklapp/formelblad before an exam.

## Steps, in order

1. Open the course folder: `/Users/Kais/Documents/Claude/Projects/<COURSE_CODE>/`. If it doesn't exist or has no exam PDFs, STOP and ask Kais to drop materials in — do not improvise from general knowledge. (As of July 2026, 747G06, TSRT19, TMKM12, TMKO05 and TMME28 have no folders.)
2. Read the *kursinformation* PDF first. Extract: exam date, number of questions, total points, G/VG thresholds, examiner(s) and which questions each examiner owns, allowed aids ("hjälpmedel"). This becomes the header block.
3. Read every past exam **med svar** (files are named like `016B 770G36 tenta1 med svar VT2025.pdf`; the matching `016A ... utan svar` is the question-only version). Identify which topic each question slot repeats ("Q4 is always fullständig konkurrens").
4. Extract **only** formulas and facts that actually appear in past-exam solutions. Group them by topic, ordered the way the exam is ordered.
5. Write `fusklapp_<COURSE_CODE>.md` **in Swedish** into the course folder, with:
   - Header blockquote: exam date · question count · points · G/VG thresholds · examiners · hjälpmedel.
   - One sentence naming the course's "röda tråd" (the single question the whole course answers).
   - Sections per topic (`## DEL 0/1/2...`) with formulas in backticks or `$$..$$`, comparison tables, and bold geometric/structural facts that "måste fastna".
   - `> **Typuppgift ...**` callouts that map a topic to a *specific past-exam question* and sketch the solution path.
   - `> **Bra att memorera:**` callouts for small facts used constantly.
6. Offer to convert to .docx or printable HTML — Kais prints fusklappar when hjälpmedel allows "lösblad" (existing ones exist as .md, .docx and .html).

## Example of a good final output (excerpt from the real `770G37/Fusklapp_770G37_Mikroekonomi.md`)

```markdown
# Fusklapp — Mikroekonomi 770G37 (VT 2026)

> **Tentan:** 1 juni 2026 · 6 frågor · 50 p · G = 25 p, VG = 37 p
> **Examinatorer:** Elisabeth Lång (Q1–3, marknadsformer/allmän jämvikt/sant-falskt) & Jonathan Siverskog (Q4–6, fullständig konkurrens/kostnadssamband/externa effekter)
> **Hjälpmedel:** miniräknare, linjal, lösblad

Kursen handlar i grunden om **EN fråga**: *hur kan vi fördela begränsade resurser effektivt?* ...

## DEL 1 — Företagets kostnadssamband (GLS kap 7–8) — viktigt för Q4–5

| Kostnad | Formel | Tolkning |
|---|---|---|
| TC (total cost) | FC + VC | All kostnad |
| ATC | TC/Q | Genomsnittlig total |
| AFC | FC/Q | Genomsnittlig fast — **alltid fallande** |
| MC | dTC/dQ | Kostnad för en extra enhet |

**Två kritiska geometriska samband (måste fastna):**
1. **MC skär ATC och AVC i deras minimumpunkter.**
2. **ATC = AVC + AFC** ...

> **Typuppgift (Q4 på senaste tentan):** Får QD och QS, ska beräkna jämvikt, sedan
> efterfrågeökning, beräkna ny **kortsiktig** jämvikt ... Lösning: lös ekvationssystemet
> algebraiskt; använd att P_LR = P_initialt.
```

## Mistakes to avoid

- **Writing in English.** Every existing fusklapp is in Swedish; Kais studies and sits exams in Swedish.
- **Padding with textbook content that never appeared on a tenta.** The sheet must stay ~one printed page of dense material; if it wasn't in a past exam or the kursinformation, it doesn't go in.
- **Skipping the exam meta block.** Thresholds, examiner split and hjälpmedel lead the real fusklappar — they drive study priorities.
- **Guessing formulas or exam structure.** Kais's standing instruction: "Don't guess. Base everything on what's actually in these files."
- **Generic summaries instead of exam mapping.** The value is callouts like "kommer i Q4!" that tie each section to a question slot.
