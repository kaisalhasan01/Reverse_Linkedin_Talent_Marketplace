---
name: launch-runbook
description: Write a step-by-step LAUNCH.md so Kais can launch a project in September 2026 with a lighter model and no prior context. Use when finishing heavy work on a project or when Kais mentions launching after the exams.
---

# Launch runbook writer

**When to use:** A project's build phase is done and the remaining work is launch/operations that will happen *after* the August 2026 exam period, executed by a lighter model (Opus) with zero context from earlier sessions.

## Steps, in order

1. Know the strategy: Kais deliberately front-loads heavy work now ("before Fable disappears") and launches after his nine exams end on Aug 27, 2026. The runbook's reader is a fresh model in September. Assume nothing.
2. Pull the launch facts from the project's own docs — never invent steps:
   - **AdulthoodCalc** (`/Users/Kais/Adulthood calc/`): README "Checklista före lansering" + MONETIZATION.md Fas 0–2 (domain, Cloudflare Pages, Search Console, TikTok Business account, later AdSense + CMP + CSP changes).
   - **Reverse LinkedIn** (`/Users/Kais/Reverse linkedin/`): README roadmap — Stripe subscriptions, deploy Vercel + Supabase.
   - **Car Deal Finder** (`/Users/Kais/Projects/car-deal-finder/`): README — create Bright Data Web Unlocker zone, fill `.env`, run the probe, confirm `__NEXT_DATA__` field paths, then real pipeline runs.
3. Structure every runbook as: **Prerequisites** (accounts, keys, costs in kr/€) → **numbered steps with exact commands and absolute paths** → **verification after each step** ("done when you see X") → **Done when** (the end state).
4. Include the documented gotchas inline at the step where they bite (e.g. for AdSense: EU ads require a Google-certified CMP with TCF 2.2, the `_headers` CSP must be opened for the ad domains, `ads.txt` gets the real pub-ID only after approval).
5. Save as `LAUNCH.md` in the repo root and confirm each step is executable by a model that has never seen the project.

## Example of a good final output (AdulthoodCalc excerpt; commands and facts from the real README)

```markdown
# LAUNCH.md — AdulthoodCalc

## Prerequisites
- [ ] Domain (~130 kr/år). Suggestion from README: adulthoodcalc.com
- [ ] GitHub account, Cloudflare account (free tier is enough — no build step)

## Steps
1. Replace the placeholder domain everywhere:
   cd "/Users/Kais/Adulthood calc"
   sed -i '' 's/adulthoodcalc\.com/DIN-DOMÄN.com/g' sitemap.xml robots.txt
   ✅ Done when: grep -r "adulthoodcalc.com" returns nothing.
2. Check the contact email in about.html, privacy.html, terms.html
   (currently kais12679@gmail.com — consider hello@din-domän).
3. git init && git add -A && git commit -m "launch" && push to a new GitHub repo.
4. pages.cloudflare.com → Create a project → connect the repo.
   Build command: EMPTY. Output directory: / (root). Deploy.
   ✅ Done when: the site renders at the *.pages.dev URL and _headers is active
   (check response headers for Content-Security-Policy).
5. Custom domain under "Custom domains" — HTTPS is automatic.
6. Google Search Console → verify domain → submit sitemap.xml.
7. TikTok **Business account** (bio link without the 1,000-follower requirement),
   username close to the brand, site link in bio.
8. ads.txt: LEAVE the placeholder until AdSense approval (see MONETIZATION.md Fas 2).

## Done when
Site live on the custom domain · sitemap submitted · TikTok bio links to the site.
First 10 video scripts are ready in VIDEO_SCRIPTS.md — start with #1 (mortgage ⭐).
```

## Mistakes to avoid

- **Deferring decisions to the future model** ("pick a host you like"). Decisions are already made in the docs — Cloudflare Pages, TikTok Business, Adtraction/Awin. The runbook states them.
- **Skipping the legal/money steps.** MONETIZATION.md is explicit: GDPR consent (CMP, TCF 2.2) is "kritiskt, inte valfritt", affiliate pages need the disclosure line, privacy.html must be rewritten when ads go live.
- **Scheduling launch work before Aug 28, 2026.** Exams run Aug 7–27; the whole point of the runbook is that nothing needs Kais's attention until they're over.
- **Relative paths or "cd into the project".** Past sessions broke exactly there — every command uses the absolute path.
