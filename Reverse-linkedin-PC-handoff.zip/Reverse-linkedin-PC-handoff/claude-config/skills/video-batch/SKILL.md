---
name: video-batch
description: Generate a batch of 30-second TikTok video scripts for AdulthoodCalc calculators in the exact VIDEO_SCRIPTS.md format, with verified numbers. Use when Kais needs new video content or scripts.
---

# Video batch

**When to use:** Kais needs new TikTok/Shorts/Reels scripts for AdulthoodCalc (typically a batch to record in one Sunday session, per his MONETIZATION.md plan).

## Steps, in order

1. Read `/Users/Kais/Adulthood calc/VIDEO_SCRIPTS.md` — it holds the format, 10 existing scripts, and a "Fler vinklar när dessa är slut" section with angle ideas (local currencies, the 7-step series, duets vs viral takes, "comment your rent" replies).
2. Every script follows the fixed structure: **HOOK (0–3 s, one shocking number) → SCREEN (exact calculator inputs and the number that changes on screen) → SCRIPT (spoken lines) → PAYOFF (the lesson in one sentence) → CTA (always the same)**.
3. **Verify every number.** Open the calculator's logic in `/Users/Kais/Adulthood calc/assets/js/pages/<page>.js` and reproduce the math (or run the page locally with `python3 -m http.server 4173`). The hook number must be exactly what the calculator will show on screen.
4. Write scripts in **English** (they're read aloud); mark currency-variant angles (kr/€/£ — the site's currency menu reformats everything).
5. Append the batch under a dated `##` section in `VIDEO_SCRIPTS.md`, numbered continuing from the last script. Batch size 7–10 = one recording session.
6. Remind Kais of the distribution plan from MONETIZATION.md: record mobile-view screen captures (faceless), big text overlays, schedule daily via TikTok/Meta's built-in schedulers, cross-post to YouTube Shorts + Instagram Reels for 3× reach.

## Example of a good final output (script #1, verbatim from the real VIDEO_SCRIPTS.md)

```markdown
## 1. The house that costs you $34,000 to leave (mortgage.html) ⭐ starta här

**HOOK:** "If you buy a house and sell it one year later at the SAME price… you just
lost thirty-four thousand dollars."
**SCREEN:** Mortgage calculator, $400k home. Set "Sell after" to 1 → show −$34,558 vs renting.
**SCRIPT:** "Here's why. Buying costs about 3% in fees. Selling costs another 7%. And in
year one, almost your entire mortgage payment is interest — you were basically paying
rent to the bank. Watch the chart: buying only beats renting at year five."
**PAYOFF:** "Buy a home to stay, not to visit."
**CTA:** "Play with your own numbers — free calculator, link in bio."
```

## Mistakes to avoid

- **Varying the CTA.** The file is explicit: end every video with the same CTA so followers learn the pattern ("Free calculator, no signup — link in bio"). Don't get creative here.
- **Inventing hook numbers.** Every existing hook is reproducible in the calculator (−$34,558 at year 1 on mortgage.html; €48k → ~€264k on compound-interest.html). A viewer who tries the calculator and gets a different number = trust gone, and trust is the product.
- **Writing face-camera or >30 s scripts.** The format is faceless screen recording; the niche works "faceless" and the pipeline depends on it being cheap to produce.
- **New calculators instead of new angles.** Each calculator supports 5–10 angles (different amounts, ages, currencies) — months of material without building anything.
