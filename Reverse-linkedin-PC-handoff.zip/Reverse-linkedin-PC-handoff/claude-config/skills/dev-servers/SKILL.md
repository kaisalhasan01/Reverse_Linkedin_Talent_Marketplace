---
name: dev-servers
description: Start and verify Kais's project dev servers (Reverse LinkedIn etc.) without port conflicts or manual terminal juggling. Use when he wants to run/preview an app or pastes a dev-server error.
---

# Dev servers

**When to use:** Kais wants to see an app running, or something dev-server related broke ("inget syns på preview", port errors, pasted terminal output).

## Steps, in order

1. **Always use `preview_start` with `.claude/launch.json`** — never tell Kais to open terminals and run commands himself. (Tried before: he ran the two-terminal instructions from the wrong directory and got garbled errors back.)
2. For Reverse LinkedIn, the real config at `/Users/Kais/Reverse linkedin/.claude/launch.json` defines two servers — start **db first, then web**:
   - `db` — `node scripts/db-server.mjs` (embedded Postgres, port 5433)
   - `web` — `next dev` (port 3000)
   Demo logins (password `Passw0rd!`): `anna@demo.se` (candidate), `talent@acme.se` (company).
3. If the harness reports **"Port 3000 is in use by another chat's dev server"**: the app does not need port 3000 specifically → set `"autoPort": true` on the config and remove any hardcoded port args, then retry. Do not try to kill another session's server.
4. If the preview is blank ("inget syns"): check `preview_logs` for build errors, confirm the db server is up, run `npx prisma migrate dev` if the schema is missing, and check `.env` has `AUTH_SECRET`.
5. Verify before reporting: `preview_console_logs` for errors, `preview_snapshot` for content, then share a `preview_screenshot` as proof. Never say "it's running" based on the process starting.

## Example of a good final output (the real, working launch.json)

```json
{
  "version": "0.0.1",
  "configurations": [
    {
      "name": "web",
      "runtimeExecutable": "/Users/Kais/.nvm/versions/node/v24.16.0/bin/node",
      "runtimeArgs": [
        "/Users/Kais/Reverse linkedin/node_modules/next/dist/bin/next",
        "dev",
        "/Users/Kais/Reverse linkedin"
      ],
      "port": 3000
    },
    {
      "name": "db",
      "runtimeExecutable": "/Users/Kais/.nvm/versions/node/v24.16.0/bin/node",
      "runtimeArgs": [
        "/Users/Kais/Reverse linkedin/scripts/db-server.mjs"
      ],
      "port": 5433
    }
  ]
}
```

(Improvement to apply when touched next: add `"autoPort": true` to `web` — the port-3000 collision has already happened once.)

## Mistakes to avoid

- **Giving manual multi-terminal instructions.** Observed failure: Kais pasted `cd "/Users/Kais/Reverse linkedin" && npm run db:dev ...` output back, confused — his shell was in `~/Downloads/OneDrive_2_6-17-2026`, not the repo. Use preview tools; if a path must be typed, make it absolute.
- **Hardcoding port 3000.** It collided with another chat's server. `autoPort: true` + no `--port` flags.
- **Starting `web` before `db`.** Next.js boots fine but every page that touches Prisma fails; the blank-preview report followed exactly this.
- **Claiming success without looking.** "Inget syns på preview" came after a server was started but never verified. Screenshot or it didn't happen.
