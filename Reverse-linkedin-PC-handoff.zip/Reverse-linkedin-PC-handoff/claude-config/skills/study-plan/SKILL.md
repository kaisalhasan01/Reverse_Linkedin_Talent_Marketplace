---
name: study-plan
description: Build or update Kais's HP-weighted study plan backwards from his Google Calendar exam dates, around his fixed Vakna/Plugg routine. Use when he asks to plan or replan studying ("studieplan", "plugga inför tentorna").
---

# Study plan

**When to use:** Kais wants a study plan for an exam period, or wants the existing one updated after a drill session or a schedule change.

## Steps, in order

1. Read exams from Google Calendar (`list_events` over the exam window). Exams are events titled with a course code whose description holds the HP (e.g. "6,5HP"). The August 2026 set:

   | Datum | Kurs | HP |
   |---|---|---|
   | 7 aug 08–12 | 732G93 | 5.5 |
   | 13 aug 08–12 | 747G06 | 8 |
   | 14 aug 08–13 | 770G36 | 6.5 |
   | 20 aug 08–12 | TMHL24 | 4.5 |
   | 21 aug 08–13 | TSRT19 | 4.5 |
   | 24 aug 08–12 | TMKM12 | 4 |
   | 25 aug 08–12 | TMKO05 | 3 |
   | 27 aug 08–13 | TATA42 | 6 |
   | 27 aug 14–19 | TMME28 | 6 |

   (730G71 appears in Kais's own plan list but has no calendar event — ask about it.)
2. Respect the fixed routine in the calendar: **Vakna 05:00** daily and **Plugg 18:00–20:00** daily. July capacity = the Plugg block + whatever he adds; from August he intends to study full-time (job ends, boss asked for August off).
3. Weight study days by HP and by drill-log weakness (see `drill-log.md` files in `/Users/Kais/Documents/Claude/Projects/<COURSE>/`). More HP + weaker topics = more days.
4. Hard rules: the last 2 days before each exam belong to that course only (tenta-drill + fusklapp review). **Watch the double exam day: TATA42 (08:00) and TMME28 (14:00) are both on Aug 27** — both must be exam-ready by Aug 25 evening.
5. Write the plan to `/Users/Kais/Documents/Claude/Projects/STUDYPLAN.md`: a week-by-week table first, then day-by-day for exam weeks, each day naming course + concrete activity (chapter, tenta id, fusklapp).
6. Offer to mirror the plan into Google Calendar events — **ask before creating events**, never overwrite his existing ones.

## Example of a good final output (excerpt — final stretch, built from the real exam dates)

```markdown
## Vecka 25–27 aug (slutspurten)

| Dag | Fokus | Aktivitet |
|---|---|---|
| Tis 25 aug | TMKO05 **TENTA 08–12** | Em: vila. Kväll (Plugg 18–20): TATA42 drillpass, tenta utan svar |
| Ons 26 aug | TATA42 + TMME28 | Fm: TATA42 fusklapp + svaga uppgiftstyper. Em: TMME28 drillpass. Kväll: gå igenom båda fusklapparna, packa hjälpmedel |
| Tor 27 aug | **DUBBELDAG** | 08–13 TATA42 tenta. Lunch + återhämtning. 14–19 TMME28 tenta. Klar! 🎉 |

**Regel för dubbeldagen:** inget nytt material efter 26 aug kl 20 — bara fusklapp-repetition.
```

## Mistakes to avoid

- **Ignoring the existing routine.** The plan must build around Vakna 05:00 and Plugg 18–20, not fight them — those events already exist in his calendar.
- **Equal time per course.** 747G06 is 8 HP, TMKO05 is 3 HP; weighting by HP (and drill-log weakness) is the whole point.
- **Planning sessions for courses with no materials without flagging it.** If the course folder is empty/missing, the plan must say "SKAFFA MATERIAL" as the first task, not pretend content exists.
- **Missing the Aug 27 collision.** Any plan that has TATA42 or TMME28 prep starting after Aug 25 has failed.
- **Writing calendar events without asking.** Kais curates his own calendar; propose, then create on approval.
