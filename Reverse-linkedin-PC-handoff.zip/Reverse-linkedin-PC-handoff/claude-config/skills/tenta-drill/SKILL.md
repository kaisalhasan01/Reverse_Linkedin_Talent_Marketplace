---
name: tenta-drill
description: Drill Kais through a past LiU exam one question at a time, grade against the facit, and log weak topics per course. Use when Kais wants to practice/öva/drilla a tenta for a course code.
---

# Tenta drill

**When to use:** Kais wants to practice a past exam ("kör en tenta", "drilla TMHL24", "öva på gamla tentor").

## Steps, in order

1. Open `/Users/Kais/Documents/Claude/Projects/<COURSE_CODE>/`. Find a **paired** exam: the `...A ... utan svar` PDF (questions only) and its `...B ... med svar` twin (with solutions) — e.g. `016A 770G36 tenta1 utan svar vt25.pdf` + `016B 770G36 tenta1 med svar VT2025.pdf`. Prefer the most recent exam not yet in the drill log.
2. Check `drill-log.md` in the same folder (if it exists) to avoid repeating an exam and to know which topics are weak.
3. Present **one question at a time**, verbatim in Swedish, with its point value. Do not show the rest of the exam.
4. Wait for Kais's answer. Never reveal the solution before he answers or explicitly gives up.
5. Grade against the med-svar facit: points earned, what was right, where the method went wrong — then walk the correct solution path showing **every step, naming the rule/formula each step uses**. Never assume a basic is known (Kais's standing complaint: explanations that skip "obvious" steps). If the solution needs a concept he hasn't proven he knows, take a short detour: everyday analogy first, then the math. If a whole topic collapses, switch to the `tenta-coach` skill for that topic before drilling on.
6. After the last question, append a session entry to `/Users/Kais/Documents/Claude/Projects/<COURSE_CODE>/drill-log.md` and give a verdict: total vs G/VG threshold, the 2–3 weakest topics, and which fusklapp section to reread.

## Example of a good final output (session summary + log entry; format grounded in the real 770G36 files and its exam structure)

```markdown
## Drillpass 2026-08-10 — 770G36, tenta 016 (VT2025)

| Fråga | Ämne | Poäng |
|---|---|---|
| 1 | BNP-beräkning (utgiftsmetoden) | 7/8 |
| 2 | Arbetsmarknaden, jämviktsarbetslöshet | 4/8 |
| 3 | Sant/falskt, tillväxtteori | 8/10 |
| 4 | Faktormarknader | 6/8 |
| 5 | Internationell handel (komparativa fördelar) | 3/8 |
| 6 | Ekonomisk tillväxt, Solow | 6/8 |

**Totalt: 34/50 — G (25 p) klarad, 3 p från VG (37 p).**

**Svagast:** internationell handel (Q5) och arbetsmarknaden (Q2).
**Nästa steg:** läs om "Kompedium int handel JPH.pdf" + fusklappens handelsdel,
kör sedan Q2+Q5 från tenta 017A innan nästa hela drillpass.
```

## Mistakes to avoid

- **Dumping the whole exam at once.** One question, wait, grade, next — the loop is the value.
- **Revealing the facit early.** The med-svar PDF is for grading, not for reading along.
- **Improvising questions for courses with no materials.** If the folder is missing (as of July 2026: 747G06, TSRT19, TMKM12, TMKO05, TMME28), ask Kais to add old tentor — "Don't guess" is his explicit rule.
- **Grading vibes instead of the facit.** Always anchor points and method to the med-svar solution.
- **Skipping steps in the facit walkthrough.** "Sen förenklar vi och får X" is exactly the failure Kais has called out — show the simplification, name the rule.
- **Forgetting the log.** Without `drill-log.md`, the weak-topic tracking that makes repeat sessions smarter is lost.
