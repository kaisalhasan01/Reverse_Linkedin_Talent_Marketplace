---
name: project-context
description: Write or refresh CLAUDE.md/AGENTS.md for one of Kais's projects so a fresh session needs zero re-explaining. Use at the start of work on any repo whose CLAUDE.md is missing, thin, or stale.
---

# Project context writer

**When to use:** Starting work in one of Kais's repos and its CLAUDE.md/AGENTS.md doesn't fully answer "what is this, what's decided, how do I run it".

## Steps, in order

1. Read `README.md`, the dependency manifest (`package.json`/`requirements.txt`), key configs, and any planning docs (`MONETIZATION.md`, roadmaps). Skim recent git log if available.
2. Capture four things, in this order:
   - **Goal** in one paragraph (what it is, who it's for, how it makes money if applicable).
   - **Decisions already made and WHY** — the "don't reopen this" list. This is the most important section.
   - **How to run/verify** — exact commands, ports, demo logins.
   - **Current state** — roadmap done vs pending, what the next milestone is.
3. Bake in Kais's standing preferences (all observed in his sessions):
   - Communicate in **Swedish**; code/docs may be English.
   - Explain as you go — his words: "säg till vad du gör så att jag hänger med".
   - He grants "full frihet" on implementation but wants a walkthrough of what was done afterwards.
   - Aesthetics are a requirement, not polish — "De ska ha fina grafer och vara esthetically pleasing!"
   - Projects must end up launch-ready for a lighter model to operate later (his Fable-window strategy: heavy lifting now, launch with Opus after the August 2026 exams).
4. Write `CLAUDE.md` at the repo root (or update `AGENTS.md` and keep `CLAUDE.md` as `@AGENTS.md`, the pattern already used in `/Users/Kais/Reverse linkedin/`). Keep it under ~60 lines.

## Example of a good final output (for Reverse LinkedIn; every fact from its real README)

```markdown
# Reverse — context for agents

Talent marketplace that flips LinkedIn: individuals build profiles for free,
companies pay to search and reach them. Candidates toggle "Looking for work";
recruiters send structured offers (title, salary, hours) — companies apply to you.

## Decided — don't reopen
- **No gender/age fields or filters anywhere** (diskrimineringslagen 2008:567 + GDPR
  data minimisation). Compliance by design, not by UI hiding.
- **"Employed = hidden" is enforced in the search SQL** and re-checked on the detail
  page — never only in the UI.
- **`/candidate/*` and `/company/*` are separate route subtrees**, not route groups —
  both need e.g. `/messages` and groups collapse to the same URL.
- **Authorization lives in the data layer**: every server action re-checks the session
  and ownership is part of the query itself.
- Stack: Next.js 16 App Router, TypeScript, PostgreSQL (embedded local / Supabase prod),
  Prisma, Auth.js v5, Tailwind v4, Zod on every server action.

## Run
npm run db:dev   # embedded Postgres, port 5433 (terminal 1)
npm run dev      # app on :3000 — prefer preview_start via .claude/launch.json
Demo logins (password Passw0rd!): anna@demo.se (candidate), talent@acme.se (company)

## State
Phases 1–6 + Wave 2 done (search, messaging, offers, feed, GDPR export/delete, CV import).
Pending: Stripe subscriptions, deploy (Vercel + Supabase). Launch window: Sept 2026.
```

## Mistakes to avoid

- **Re-litigating settled decisions.** The observed failure mode: every new session, Kais re-explains the project and grants "full frihet" again. The "Decided — don't reopen" section exists to kill that loop.
- **Duplicating the README at length.** Point to it; only restate what an agent must know before touching anything.
- **Omitting run commands and demo credentials.** Dev-server confusion cost real time in past sessions (see the `dev-servers` skill).
- **Writing for yourself instead of a lighter model.** September-launch work will be done by Opus without this conversation's context; if a step needs Fable-level inference, spell it out instead.
